#!/bin/bash

echo ""
echo " ************************************************** "
echo "                        声明                        "
echo "                                                    "
echo "            该安装包基于张根深开发的install          "
echo "                    升级版install2.0                "
echo "       修改后供hfutrobocup成员参考/学习/开发使用     "
echo "                                                    "
echo "                 安装环境 Ubuntu14.10               "
echo "                                                    "
echo "       	作     者 ： 周青波     何 磊                "
echo "                                                    "
echo " ************************************************** "
echo -e "\n\n\n"

#更新源
sudo apt-get update
echo -e "\n\n\n"
echo " ************************************************** "
echo "                                                    "
echo "              Ubuntu14.10更新源完毕                 "
echo "            两秒钟之后开始安装平台支持库             "
echo "                                                    "
echo " ************************************************** "
echo -e "\n\n\n"
sleep 3 

#安装平台支持库
sudo apt-get install -y build-essential libboost-all-dev flex 

sudo apt-get install -y libqt4-dev libxpm-dev libaudio-dev libxt-dev libpng-dev libglib2.0-dev libfreetype6-dev libxrender-dev libxext-dev libfontconfig-dev libxi-dev

tar -zxvf bison-2.7.1.tar.gz
cd bison-2.7.1
./configure
make
sudo make install
cd ..

sudo ldconfig

echo -e "\n\n\n"
echo " ************************************************** "
echo "                                                    "
echo "             Ubuntu14.10中平台支持库安装完毕         "
echo "                   两秒钟安装常用软件                "
echo "            g++/meld/nautilus-open-terminal         "
echo "                                                    "
echo " ************************************************** "
echo -e "\n\n\n"
sleep 3 

#安装软件
sudo apt-get install -y g++
sudo apt-get install -y meld
sudo apt-get install -y nautilus-open-terminal
echo -e "\n\n\n"
echo " ************************************************** "
echo "                                                    "
echo "             Ubuntu14.10常用软件安装完毕             "
echo "           两秒钟之后安装rcssserver-15.2.2           "
echo "                                                    "
echo " ************************************************** "
echo -e "\n\n\n"
sleep 3 

#下面安装rcssserver/rcsslogplayer/rcssmonitor等
tar -zxvf rcssserver-15.2.2.tar.gz
cd rcssserver-15.2.2 
./configure --with-boost-libdir=/usr/lib/x86_64-linux-gnu
make
sudo make install
cd ..
echo -e "\n\n\n"
echo " ************************************************** "
echo "                                                    "
echo "           Ubuntu14.10中 rcssserver 安装完毕 ！     "
echo "              两秒之后安装 rcsslogplayer            "
echo "                                                    "
echo " ************************************************** "
echo -e "\n\n\n"
sleep 3

tar -zxvf rcsslogplayer-15.1.0.tar.gz
cd rcsslogplayer-15.1.0
./configure --disable-gl --with-boost-libdir=/usr/lib/x86_64-linux-gnu
make
sudo make install
cd ..
echo -e "\n\n\n"
echo " ************************************************** "
echo "                                                    "
echo "         Ubuntu14.10 中 rcsslogplayer 安装完毕！      "
echo "             两秒之后安装 rcssmonitor                "
echo "                                                    "
echo " ************************************************** "
echo -e "\n\n\n"
sleep 3

tar -zxvf rcssmonitor-15.1.0.tar.gz
cd rcssmonitor-15.1.0 
./configure --with-boost-libdir=/usr/lib/x86_64-linux-gnu
make
sudo make install
cd ..
echo -e "\n\n\n"
echo " ************************************************** "
echo "                                                    "
echo "          Ubuntu14.10中 rcssmonitor 安装完毕！       "
echo "              两秒之后安装 librcsc-4.1.0           "
echo "                                                    "
echo " ************************************************** "
echo -e "\n\n\n"
sudo ldconfig
sleep 3



#安装 librcsc-4.1.0 底层动作库
cd librcsc-4.1.0
./configure
make
sudo make install
cd ..
echo -e "\n\n\n"
echo " ************************************************** "
echo "                                                    "
echo "          Ubuntu14.10 中 librcsc-4.1.0 安装完毕！    "
echo "              两秒之后安装 soccerwindow2-5.1.0       "
echo "                                                    "
echo " ************************************************** "
echo -e "\n\n\n"
sudo ldconfig
sleep 3

cd  soccerwindow2-5.1.0
./configure
make
sudo make install
cd ..
echo -e "\n\n\n"
echo " ************************************************** "
echo "                                                    "
echo "     Ubuntu14.10 中 soccerwindow2-5.1.0 安装完毕！   "
echo "              两秒之后安装 fedit2-0.0.0             "
echo "                                                    "
echo " ************************************************** "
echo -e "\n\n\n"
sleep 3

#安装阵型修改器
cd fedit2-0.0.0
./configure
make
sudo make install
cd ..
echo -e "\n\n\n"
echo " ************************************************** "
echo "                                                    "
echo "          Ubuntu14.10 中 fedit2-0.0.0 安装完毕！     "
echo "                   所有软件安装完毕！                "
echo "                                                    "
echo " ************************************************** "
echo -e "\n\n\n"
sudo ldconfig



echo -e "\n\n\n"
echo " ************************************************** "
echo "                                                    "
echo "                     Ubuntu14.10                    "
echo "                                                    "
echo "                 平台/支持库等安装完毕              "
echo "                请重启或者注销系统后使用             "
echo "                                                    "
echo "          重启后在软件中心或终端安装kdevelop          "
echo "               Date   : 2015/03/15                   "
echo "                                                    "
echo "                                                    "
echo " ************************************************** "
echo -e "\n\n\n"









